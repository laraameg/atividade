// Import the functions you need from the SDKs you need
import firebase from "firebase";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDZ7q4Bpg6gqY8Z6ebMPBRISYTM7jPxKUY",
  authDomain: "botao-b2cab.firebaseapp.com",
  databaseURL: "https://botao-b2cab-default-rtdb.firebaseio.com",
  projectId: "botao-b2cab",
  storageBucket: "botao-b2cab.appspot.com",
  messagingSenderId: "548951815405",
  appId: "1:548951815405:web:7fe910543613506ab0c8e4"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
export default app.database();